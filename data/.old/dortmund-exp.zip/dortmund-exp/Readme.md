## Todo

1. Numerical/Interval Results
    - Split inference/figure
    - Extract raw values (NOT >0.8 binarization)
2. Changes in inference type
    - Patterns consistent across inference type?

## Visualizations

## Data

- element_id: Shows if row contains answer
- answer_value: Contains answers
- subject_group: Identifies what tasks were posed
- hidden_min/hidden_max: Shown interval
